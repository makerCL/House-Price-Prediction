# House-Price-Prediction
94th percentile solution for accuracy out of 66,000 participants in the Kaggle Machine Learning Competition. Used XGBRegressor to predict the sale price of houses based on a number of features

Competition:
https://www.kaggle.com/c/home-data-for-ml-course
